
public class Main {

	public static void main(String[] args) {
		
		ElgamalSystem Alice = new ElgamalSystem();
		ElgamalSystem Bob = new ElgamalSystem();
		String pathToFile = "C:\\Users\\lizfr\\Downloads\\kek.txt";
		
		Alice.MessageSignature(pathToFile);
		Bob.SignatureVerification(pathToFile, Alice.getKeysForVerificationMessage());
		
		Alice.Encryption(pathToFile, Bob.getOpenKeysForEncryption());
		Bob.Decryption(Alice.getCipherText());
		
	}
}
